import Home from './Components/Home';
import './App.css';

function App() {
  return (
    <div className="">
    <Home/>
    </div>
  );
}

export default App;
