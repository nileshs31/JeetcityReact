
import './App.css';
import Champions from './Components/Champions';
function App() {
  return (
    <div className="">
      <Champions/>

    </div>
  );
}

export default App;
